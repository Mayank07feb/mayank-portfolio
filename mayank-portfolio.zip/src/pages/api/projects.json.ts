export async function GET() {
  const projects = [
    {
      id: 1,
      title: "Fashion",
      category: "Fashion",
      description: "Brand Identity & Social Media Design",
      image: "/assets/img/portfolio/800/fashion.png",
      alt: "Fashion Brand Design",
      slug: "fashion",
    },
    {
      id: 2,
      title: "Healthcare",
      category: "Healthcare",
      description: "Brand Identity & Stationery Design",
      image: "/assets/img/portfolio/800/healthcare.png",
      alt: "Healthcare Branding",
      slug: "healthcare",
    },
    {
      id: 3,
      title: "Automobiles",
      category: "Automobiles",
      description: "Marketing Campaigns & Visual Creatives",
      image: "/assets/img/portfolio/800/automobile.png",
      alt: "Automobiles Branding",
      slug: "automobiles",
    },
    {
      id: 4,
      title: "Events",
      category: "Events",
      description: "Event Branding & Promotional Design",
      image: "/assets/img/portfolio/800/events.png",
      alt: "Event Branding",
      slug: "events",
    },
    {
      id: 5,
      title: "Hospitality & Food",
      category: "Hospitality & Food",
      description: "Packaging & Brand Visual Design",
      image: "/assets/img/portfolio/800/hospitality-food.png",
      alt: "Hospitality & Food Branding",
      slug: "hospitality-food",
    },
    {
      id: 6,
      title: "Fitness",
      category: "Fitness",
      description: "Brand Identity & Social Media Design",
      image: "/assets/img/portfolio/800/fitness.png",
      alt: "Fitness Branding",
      slug: "fitness",
    },
  ];

  return new Response(JSON.stringify(projects), {
    status: 200,
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "no-store", // best for SSR
    },
  });
}
