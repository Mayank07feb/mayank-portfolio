const API_KEY = import.meta.env.PRIVATE_API_KEY;

export async function secureFetch(endpoint) {
  return fetch(endpoint, {
    headers: {
      Authorization: `Bearer ${API_KEY}`,
    },
  });
}
