const BASE_URL = import.meta.env.PUBLIC_API_BASE_URL;

export async function fetchAPI(endpoint) {
  const res = await fetch(`${BASE_URL}${endpoint}`);
  return res.json();
}
